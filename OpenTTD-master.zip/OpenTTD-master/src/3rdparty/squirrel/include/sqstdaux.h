/*	see copyright notice in squirrel.h */
#ifndef _SQSTD_AUXLIB_H_
#define _SQSTD_AUXLIB_H_

void sqstd_seterrorhandlers(HSQUIRRELVM v);
void sqstd_printcallstack(HSQUIRRELVM v);

#endif /* _SQSTD_AUXLIB_H_ */
